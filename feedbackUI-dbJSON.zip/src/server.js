import { Model, belongsTo, createServer, hasMany } from "miragejs";

let server = createServer();
server.get("/api/feedbacks", {
  feedbacks: [
    {
      id: 1,
      rating: 10,
      text: "This is feedback item 1 coming from the backend",
    },
    {
      id: 2,
      rating: 6,
      text: "This is feedback item 1 coming from the backend",
    },
    {
      id: 3,
      rating: 9,
      text: "This is feedback item 1 coming from the backend",
    },
  ],
});
