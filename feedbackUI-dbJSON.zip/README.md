Ferramenta que recebe feedbacks com comentários e notas, podem sera atualizados e/ou excluídas.
Link para visualizar: https://63f8c1f2ea718505ad09a423--transcendent-sprinkles-163db9.netlify.app/;
